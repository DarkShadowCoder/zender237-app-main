import React, {
  useCallback,
  useEffect,
  useState,
} from 'react';

import {
  ScrollView,
  Alert,
  View,
  Text,
  Pressable,
  StyleSheet,
} from 'react-native';

import {
  Ionicons,
} from '@expo/vector-icons';

import {
  colors,
  typography,
  spacing,
  radii,
  shadows,
  components,
  transactionTypeColors,
  fontWeights,
  lineHeights,
} from '../../../theme/theme';

import {
  formatAmount,
} from '../../../utils/formatters';

import Button from '../../../components/Button';

import {
  getTransaction,
} from '../../../services/adminService';

import {
  supabase,
} from '../../../lib/supabase';

import {
  Screen,
  Loading,
  ErrorBox,
} from '../AdminUI';


/* ============================================================
 * CONSTANTS
 * ============================================================ */

const TYPE_ICONS = {
  deposit:
    'arrow-down-circle',

  transfer:
    'swap-horizontal',

  withdrawal:
    'arrow-up-circle',
};

const TERMINAL_STATUSES = [
  'completed',
  'confirmed',
  'rejected',
  'cancelled',
];


/* ============================================================
 * ADMIN TRANSACTION ACTION
 * ============================================================ */

/**
 * Toutes les actions administrateur passent par l'Edge Function
 * `admin-transaction-action`.
 *
 * Cela évite de dupliquer la logique métier côté mobile et garantit
 * que les vérifications admin restent exécutées côté serveur.
 */
async function executeAdminTransactionAction({
  transactionId,
  action,
  reason = null,
}) {
  if (!transactionId) {
    throw new Error(
      'transactionId est requis.'
    );
  }

  if (!action) {
    throw new Error(
      'Action de transaction requise.'
    );
  }

  const {
    data,
    error,
  } =
    await supabase.functions.invoke(
      'admin-transaction-action',
      {
        body: {
          transactionId,
          action,
          reason:
            reason
              ? String(
                  reason
                ).trim()
              : null,
        },
      }
    );

  /*
   * Supabase peut retourner une FunctionsHttpError avec
   * un corps JSON contenant le vrai message de l'Edge Function.
   */
  if (error) {
    let message =
      error?.message ||
      'Impossible de traiter la transaction.';

    try {
      const context =
        error?.context;

      if (
        context &&
        typeof context.json ===
          'function'
      ) {
        const body =
          await context.json();

        if (
          body?.message
        ) {
          message =
            body.message;
        }
      }
    } catch (_) {
      // On conserve le message Supabase si le body ne peut pas être lu.
    }

    const actionError =
      new Error(
        message
      );

    actionError.code =
      data?.code ||
      error?.code ||
      null;

    actionError.details =
      data ||
      null;

    throw actionError;
  }

  if (
    data?.success ===
    false
  ) {
    const actionError =
      new Error(
        data?.message ||
          'Impossible de traiter la transaction.'
      );

    actionError.code =
      data?.code ||
      null;

    actionError.details =
      data;

    throw actionError;
  }

  return (
    data?.transaction ||
    data
  );
}


async function approveTransaction({
  transactionId,
}) {
  return executeAdminTransactionAction({
    transactionId,
    action:
      'approve',
  });
}


async function rejectTransaction({
  transactionId,
  reason,
}) {
  return executeAdminTransactionAction({
    transactionId,
    action:
      'reject',
    reason,
  });
}


async function cancelTransaction({
  transactionId,
  reason,
}) {
  return executeAdminTransactionAction({
    transactionId,
    action:
      'cancel',
    reason,
  });
}


/* ============================================================
 * STATUS
 * ============================================================ */

function getStatusBanner(
  status
) {
  if (
    status ===
      'confirmed' ||
    status ===
      'completed'
  ) {
    return {
      title:
        'Transaction confirmée',

      badge:
        'Confirmée',

      color:
        colors.success.default,
    };
  }

  if (
    status ===
    'rejected'
  ) {
    return {
      title:
        'Transaction rejetée',

      badge:
        'Rejetée',

      color:
        colors.error.default,
    };
  }

  if (
    status ===
    'cancelled'
  ) {
    return {
      title:
        'Transaction annulée',

      badge:
        'Annulée',

      color:
        colors.text.tertiary,
    };
  }

  return {
    title:
      'Transaction en cours',

    badge:
      'En attente',

    color:
      colors.brand.primary,
  };
}


/* ============================================================
 * DATE
 * ============================================================ */

function fmtDT(
  iso
) {
  if (!iso) {
    return null;
  }

  const d =
    new Date(iso);

  const date =
    d.toLocaleDateString(
      'fr-FR',
      {
        day:
          '2-digit',

        month:
          'long',

        year:
          'numeric',
      }
    );

  const time =
    d.toLocaleTimeString(
      'fr-FR',
      {
        hour:
          '2-digit',

        minute:
          '2-digit',
      }
    );

  return `${date} - ${time}`;
}


function fmtDate(
  iso
) {
  if (!iso) {
    return null;
  }

  return new Date(
    iso
  ).toLocaleDateString(
    'fr-FR',
    {
      day:
        '2-digit',

      month:
        'long',

      year:
        'numeric',
    }
  );
}


/* ============================================================
 * TIMELINE
 * ============================================================ */

function buildSteps(
  t
) {
  const success =
    t.status ===
      'confirmed' ||
    t.status ===
      'completed';

  const stopped =
    t.status ===
      'rejected' ||
    t.status ===
      'cancelled';

  const steps = [
    {
      key:
        'created',

      label:
        'Demande initiée',

      timestamp:
        t.created_at,

      done:
        true,
    },

    {
      key:
        'review',

      label:
        'Paiement validé',

      timestamp:
        t.first_reviewed_at,

      done:
        !!t.executed_at ||
        success,
    },

    {
      key:
        'execution',

      label:
        "En attente d'exécution",

      timestamp:
        t.executed_at,

      done:
        !!t.settled_at ||
        success,
    },

    {
      key:
        'confirmation',

      label:
        'Confirmation administrateur',

      timestamp:
        t.settled_at,

      done:
        success,
    },
  ];

  const pendingIndex =
    steps.findIndex(
      (
        s
      ) => !s.done
    );

  return steps.map(
    (
      s,
      i
    ) => ({
      ...s,

      isCurrent:
        !stopped &&
        i ===
          pendingIndex,

      isStopped:
        stopped &&
        i ===
          pendingIndex,
    })
  );
}


/* ============================================================
 * SCREEN
 * ============================================================ */

export default function AdminTransactionDetailScreen({
  route,
  navigation,
}) {
  const {
    transactionId,
  } =
    route.params;

  const [
    d,
    setD,
  ] =
    useState(null);

  const [
    loading,
    setLoading,
  ] =
    useState(true);

  const [
    actionLoading,
    setActionLoading,
  ] =
    useState(false);

  const [
    error,
    setError,
  ] =
    useState(null);

  const [
    infoExpanded,
    setInfoExpanded,
  ] =
    useState(false);


  /* ==========================================================
   * LOAD
   * ========================================================== */

  const load =
    useCallback(
      async () => {
        try {
          setError(
            null
          );

          const result =
            await getTransaction(
              transactionId
            );

          setD(
            result
          );
        } catch (
          e
        ) {
          console.error(
            '[AdminTransactionDetail] load:',
            e
          );

          setError(
            e?.message ||
              'Impossible de charger la transaction.'
          );
        } finally {
          setLoading(
            false
          );
        }
      },
      [
        transactionId,
      ]
    );


  useEffect(
    () => {
      load();
    },
    [load]
  );


  /* ==========================================================
   * ACTION
   * ========================================================== */

  const act =
    async (
      fn,
      title,
      options = {}
    ) => {
      try {
        /*
         * Sécurité supplémentaire :
         * on évite exactement l'erreur
         * "fn is not a function".
         */
        if (
          typeof fn !==
          'function'
        ) {
          throw new Error(
            'Action administrative indisponible.'
          );
        }

        setActionLoading(
          true
        );

        await fn({
          transactionId,

          ...(options.reason
            ? {
                reason:
                  options.reason,
              }
            : {}),
        });

        Alert.alert(
          title,
          'Opération enregistrée.'
        );

        await load();
      } catch (
        e
      ) {
        console.error(
          '[AdminTransactionDetail] action:',
          e
        );

        let message =
          e?.message ||
          'Une erreur est survenue.';

        /*
         * Messages plus explicites pour les cas métier
         * déjà gérés par l’Edge Function.
         */
        if (
          e?.code ===
          'INVALID_TRANSACTION_STATUS'
        ) {
          message =
            e?.message ||
            'Cette transaction ne peut plus être modifiée depuis son statut actuel.';
        }

        if (
          e?.code ===
          'ACCOUNT_DISABLED'
        ) {
          message =
            'Votre compte administrateur est désactivé.';
        }

        Alert.alert(
          'Erreur',
          message
        );
      } finally {
        setActionLoading(
          false
        );
      }
    };


  /* ==========================================================
   * CONFIRM DIALOG
   * ========================================================== */

  const confirmAct =
    (
      fn,
      title,
      question,
      options = {}
    ) => {
      Alert.alert(
        title,
        question,
        [
          {
            text:
              'Annuler',

            style:
              'cancel',
          },

          {
            text:
              'Confirmer',

            style:
              options.destructive
                ? 'destructive'
                : 'default',

            onPress:
              () =>
                act(
                  fn,
                  title,
                  options
                ),
          },
        ]
      );
    };


  /* ==========================================================
   * LOADING
   * ========================================================== */

  if (loading) {
    return (
      <Screen
        title="Transaction"
      >
        <Loading
          label="Chargement de la transaction…"
        />
      </Screen>
    );
  }


  /* ==========================================================
   * ERROR
   * ========================================================== */

  if (
    error
  ) {
    return (
      <Screen
        title="Transaction"
      >
        <ErrorBox
          message={
            error
          }
          onRetry={
            load
          }
        />
      </Screen>
    );
  }


  if (
    !d?.transaction
  ) {
    return (
      <Screen
        title="Transaction"
      >
        <ErrorBox
          message="Transaction introuvable."
          onRetry={
            load
          }
        />
      </Screen>
    );
  }


  /* ==========================================================
   * DATA
   * ========================================================== */

  const t =
    d.transaction;

  const terminal =
    TERMINAL_STATUSES.includes(
      t.status
    );

  const typeMeta =
    transactionTypeColors[
      t.type
    ] ||
    transactionTypeColors.transfer;

  const typeIcon =
    TYPE_ICONS[
      t.type
    ] ||
    'document-text-outline';

  const banner =
    getStatusBanner(
      t.status
    );

  const executionProofs =
    d.executionProofs ||
    [];

  const hasExecutionProof =
    executionProofs.length >
    0;

  const shortRef =
    t.id
      ? `TXN-${t.id
          .slice(
            0,
            3
          )
          .toUpperCase()}-${t.id
          .slice(
            3,
            7
          )
          .toUpperCase()}`
      : '—';

  const network =
    t.network ||
    t.payment_method ||
    t.momo_provider ||
    null;

  const steps =
    buildSteps(
      t
    );

  const allDone =
    steps.every(
      (
        s
      ) =>
        s.done
    );


  /* ==========================================================
   * RENDER
   * ========================================================== */

  return (
    <Screen
      title={
        typeMeta.label ||
        'Transaction'
      }
    >
      <ScrollView
        contentContainerStyle={
          local.scroll
        }
        showsVerticalScrollIndicator={
          false
        }
      >

        {/* ====================================================
         * STATUS + REFERENCE
         * ==================================================== */}

        <View
          style={[
            local.banner,
            {
              backgroundColor:
                banner.color,
            },
          ]}
        >
          <View
            style={
              local.bannerRow
            }
          >
            <View
              style={
                local.bannerIconWrap
              }
            >
              <Ionicons
                name="checkmark"
                size={15}
                color={
                  banner.color
                }
              />
            </View>

            <Text
              style={[
                typography.caption,
                local.bannerTitle,
                {
                  fontWeight:
                    fontWeights.bold,
                },
              ]}
              numberOfLines={1}
            >
              {
                banner.title
              }
            </Text>

            <View
              style={
                local.bannerBadge
              }
            >
              <Text
                style={
                  local.bannerBadgeText
                }
              >
                {
                  banner.badge
                }
              </Text>
            </View>
          </View>

          <View
            style={
              local.bannerMetaRow
            }
          >
            <Text
              style={
                local.bannerMeta
              }
            >
              {
                shortRef
              }
            </Text>

            <Text
              style={
                local.bannerMeta
              }
            >
              {
                fmtDate(
                  t.created_at
                )
              }
            </Text>
          </View>
        </View>


        {/* ====================================================
         * AMOUNT
         * ==================================================== */}

        <View
          style={
            local.card
          }
        >
          <View
            style={{
              flex: 1,

              flexDirection:
                'row',

              alignItems:
                'center',

              gap:
                spacing.xs,
            }}
          >
            <View
              style={[
                local.amountIconWrap,
                {
                  backgroundColor:
                    typeMeta.background,
                },
              ]}
            >
              <Ionicons
                name={
                  typeIcon
                }
                size={
                  24
                }
                color={
                  typeMeta.color
                }
              />
            </View>

            <Text
              style={[
                typography.amountMd,
                {
                  color:
                    typeMeta.color,

                  bottom:
                    4,
                },
              ]}
            >
              {
                typeMeta.label
              }
            </Text>
          </View>

          <Text
            style={[
              typography.caption,
              {
                lineHeight:
                  spacing.md *
                  1.4,

                fontWeight:
                  fontWeights.semiBold,
              },
            ]}
          >
            {
              formatAmount(
                t.amount
              )
            }
          </Text>
        </View>


        {/* ====================================================
         * PARTIES
         * ==================================================== */}

        <View
          style={
            local.partiesCard
          }
        >
          <View
            style={{
              flex: 1,
            }}
          >
            <Text
              style={
                local.partyLabel
              }
            >
              Expéditeur
            </Text>

            <Text
              style={[
                typography.caption,
                {
                  fontWeight:
                    fontWeights.semiBold,
                },
              ]}
              numberOfLines={1}
            >
              {
                t.profiles?.username ||
                'Utilisateur'
              }
            </Text>

            <Text
              style={
                typography.caption
              }
              numberOfLines={1}
            >
              {
                t.profiles
                  ?.whatsapp_number ||
                network ||
                '—'
              }
            </Text>
          </View>

          <View
            style={
              local.partiesDivider
            }
          />

          <View
            style={{
              flex: 1,

              justifyContent:
                'flex-end',

              alignItems:
                'flex-end',
            }}
          >
            <Text
              style={
                local.partyLabel
              }
            >
              Bénéficiaire
            </Text>

            <Text
              style={[
                typography.caption,
                {
                  fontWeight:
                    fontWeights.semiBold,
                },
              ]}
              numberOfLines={1}
            >
              {
                t.recipient_name ||
                'Non renseigné'
              }
            </Text>

            <Text
              style={
                typography.caption
              }
              numberOfLines={1}
            >
              {
                t.recipient_mobile_number ||
                network ||
                '—'
              }
            </Text>
          </View>
        </View>


        {/* ====================================================
         * GENERAL INFORMATION
         * ==================================================== */}

        <Pressable
          style={
            local.collapseHeader
          }
          onPress={() =>
            setInfoExpanded(
              (
                v
              ) =>
                !v
            )
          }
        >
          <Ionicons
            name="information-circle-outline"
            size={15}
            color={
              colors.text.secondary
            }
          />

          <Text
            style={[
              typography.caption,
              {
                flex: 1,
              },
            ]}
          >
            Informations générales
          </Text>

          <Ionicons
            name={
              infoExpanded
                ? 'chevron-up'
                : 'chevron-down'
            }
            size={16}
            color={
              colors.text.tertiary
            }
          />
        </Pressable>

        {infoExpanded ? (
          <View
            style={
              local.infoSection
            }
          >
            <InfoRow
              icon="calendar-outline"
              label="Date de demande"
              value={
                fmtDT(
                  t.created_at
                )
              }
            />

            <InfoRow
              icon="person-outline"
              label="Nom du bénéficiaire"
              value={
                t.recipient_name ||
                '—'
              }
            />

            {network ? (
              <InfoRow
                icon="card-outline"
                label="Réseau"
                value={
                  network
                }
                last
              />
            ) : null}
          </View>
        ) : null}


        {/* ====================================================
         * TRACKING + PROOF
         * ==================================================== */}

        <View
          style={
            local.card
          }
        >
          <View
            style={
              local.suiviHeader
            }
          >
            <Ionicons
              name="time-outline"
              size={15}
              color={
                colors.text.primary
              }
            />

            <Text
              style={[
                typography.bodyBold,
                {
                  flex: 1,
                },
              ]}
            >
              Suivi
            </Text>

            <View
              style={[
                local.suiviBadge,
                {
                  backgroundColor:
                    allDone
                      ? colors.success.light
                      : colors.brand.primaryLight,
                },
              ]}
            >
              <Text
                style={[
                  typography.overline,
                  {
                    color:
                      allDone
                        ? colors.success.text
                        : colors.brand.primary,
                  },
                ]}
              >
                {
                  allDone
                    ? 'Terminé'
                    : 'En cours'
                }
              </Text>
            </View>
          </View>


          {steps.map(
            (
              step,
              i
            ) => (
              <StepRow
                key={
                  step.key
                }
                step={
                  step
                }
                isLast={
                  i ===
                  steps.length -
                    1
                }
              />
            )
          )}


          <View
            style={
              local.proofRow
            }
          >
            <Ionicons
              name="image-outline"
              size={15}
              color={
                colors.text.tertiary
              }
            />

            <Text
              style={[
                typography.caption,
                {
                  flex: 1,
                },
              ]}
            >
              {hasExecutionProof
                ? `${executionProofs.length} preuve${
                    executionProofs.length >
                    1
                      ? 's'
                      : ''
                  }`
                : 'Aucune preuve ajoutée'}
            </Text>

            <Pressable
              style={({
                pressed,
              }) => [
                local.proofButton,

                pressed && {
                  opacity:
                    0.85,
                },
              ]}
              onPress={() =>
                navigation.navigate(
                  'AdminTransactionProof',
                  {
                    transactionId,
                  }
                )
              }
            >
              <Text
                style={
                  local.proofButtonText
                }
              >
                {
                  hasExecutionProof
                    ? 'Voir'
                    : 'Ajouter'
                }
              </Text>
            </Pressable>
          </View>
        </View>


        {/* ====================================================
         * CANCEL
         * ==================================================== */}

        {!terminal ? (
          <Pressable
            style={
              local.cancelLink
            }
            disabled={
              actionLoading
            }
            onPress={() =>
              confirmAct(
                cancelTransaction,

                'Transaction annulée',

                'Voulez-vous annuler définitivement cette transaction ?',

                {
                  destructive:
                    true,

                  reason:
                    'Annulation administrative',
                }
              )
            }
          >
            <Text
              style={[
                typography.caption,
                {
                  color:
                    colors.text.tertiary,
                },
              ]}
            >
              Annuler la transaction
            </Text>
          </Pressable>
        ) : null}


        {/* ====================================================
         * TERMINAL NOTICE / ACTIONS
         * ==================================================== */}

        {terminal ? (
          <View
            style={
              local.notice
            }
          >
            <Ionicons
              name="lock-closed-outline"
              size={15}
              color={
                components
                  .infoBanner
                  .iconColor
              }
            />

            <Text
              style={[
                typography.caption,
                {
                  color:
                    components
                      .infoBanner
                      .textColor,

                  flex: 1,

                  lineHeight:
                    lineHeights.md,
                },
              ]}
            >
              Transaction clôturée — aucune action n'est disponible pour ce statut.
            </Text>
          </View>
        ) : (
          <View
            style={
              local.bottomActionsRow
            }
          >
            <View
              style={{
                flex: 1,
              }}
            >
              <Button
                title="Rejeter"
                variant="outline"
                loading={
                  actionLoading
                }
                disabled={
                  actionLoading
                }
                onPress={() =>
                  confirmAct(
                    rejectTransaction,

                    'Transaction rejetée',

                    'Voulez-vous rejeter cette transaction ? Cette action est irréversible.',

                    {
                      destructive:
                        true,
                    }
                  )
                }
              />
            </View>

            <View
              style={{
                flex: 1,
              }}
            >
              <Button
                title="Confirmer"
                variant="primary"
                loading={
                  actionLoading
                }
                disabled={
                  actionLoading
                }
                onPress={() =>
                  act(
                    approveTransaction,
                    'Transaction confirmée'
                  )
                }
              />
            </View>
          </View>
        )}
      </ScrollView>
    </Screen>
  );
}


/* ============================================================
 * INFO ROW
 * ============================================================ */

function InfoRow({
  icon,
  label,
  value,
  last,
}) {
  return (
    <View
      style={[
        local.infoRow,
        !last &&
          local.infoRowBorder,
      ]}
    >
      <Ionicons
        name={icon}
        size={14}
        color={
          colors.text.tertiary
        }
      />

      <Text
        style={[
          typography.caption,
          {
            flex: 1,
          },
        ]}
      >
        {
          label
        }
      </Text>

      <Text
        style={[
          typography.caption,
          {
            fontWeight:
              fontWeights.regular,
          },
        ]}
        numberOfLines={1}
      >
        {
          value
        }
      </Text>
    </View>
  );
}


/* ============================================================
 * STEP ROW
 * ============================================================ */

function StepRow({
  step,
  isLast,
}) {
  const icon =
    step.isStopped
      ? 'close-circle'
      : step.done
        ? 'checkmark-circle'
        : step.isCurrent
          ? 'ellipse'
          : 'ellipse-outline';

  const color =
    step.isStopped
      ? colors.error.default
      : step.done ||
          step.isCurrent
        ? colors.brand.primary
        : colors.border.default;

  const dateLabel =
    step.timestamp
      ? fmtDT(
          step.timestamp
        )
      : step.isCurrent
        ? 'En cours de traitement'
        : 'À venir';

  return (
    <View
      style={[
        local.stepRow,
        step.isCurrent &&
          local.stepRowCurrent,
      ]}
    >
      <View
        style={
          local.stepRail
        }
      >
        <Ionicons
          name={
            icon
          }
          size={16}
          color={
            color
          }
        />

        {!isLast ? (
          <View
            style={[
              local.stepLine,

              (
                step.done ||
                step.isCurrent
              ) && {
                backgroundColor:
                  colors
                    .brand
                    .primary,
              },
            ]}
          />
        ) : null}
      </View>

      <View
        style={{
          flex: 1,

          paddingBottom:
            isLast
              ? spacing.xxs
              : spacing.sm,

          bottom:
            10,
        }}
      >
        <Text
          style={[
            typography.caption,
            {
              fontWeight:
                fontWeights.semiBold,
            },

            step.isCurrent && {
              color:
                colors
                  .brand
                  .primary,
            },
          ]}
          numberOfLines={1}
        >
          {
            step.label
          }
        </Text>

        <Text
          style={[
            typography.caption,
            {
              lineHeight:
                lineHeights.md,
            },
          ]}
        >
          {
            dateLabel
          }
        </Text>
      </View>
    </View>
  );
}


/* ============================================================
 * STYLES
 * ============================================================ */

const local =
  StyleSheet.create({
    scroll: {
      paddingHorizontal:
        spacing.xxs,

      paddingTop:
        spacing.sm,

      paddingBottom:
        spacing.xl,

      gap:
        spacing.sm,
    },


    /* ------------------------------------------
     * STATUS
     * ------------------------------------------ */

    banner: {
      borderRadius:
        radii.sm,

      paddingHorizontal:
        spacing.md,

      paddingVertical:
        spacing.sm,
    },

    bannerRow: {
      flexDirection:
        'row',

      alignItems:
        'center',

      gap:
        spacing.xs,
    },

    bannerIconWrap: {
      width:
        26,

      height:
        26,

      borderRadius:
        radii.circle,

      backgroundColor:
        colors.background.surface,

      alignItems:
        'center',

      justifyContent:
        'center',
    },

    bannerTitle: {
      flex: 1,

      color:
        colors.text.inverse,
    },

    bannerBadge: {
      backgroundColor:
        'rgba(255,255,255,0.22)',

      paddingHorizontal:
        spacing.sm,

      paddingVertical:
        3,

      borderRadius:
        radii.pill,
    },

    bannerBadgeText: {
      ...typography.caption,

      lineHeight:
        spacing.md *
        1.4,

      color:
        colors.text.inverse,
    },

    bannerMetaRow: {
      flexDirection:
        'row',

      justifyContent:
        'space-between',

      paddingLeft:
        26 +
        spacing.xs,
    },

    bannerMeta: {
      ...typography.caption,

      lineHeight:
        spacing.md *
        1.4,

      color:
        'rgba(255,255,255,0.85)',
    },


    /* ------------------------------------------
     * GENERIC CARD
     * ------------------------------------------ */

    card: {
      borderRadius:
        components
          .card
          .radius,

      backgroundColor:
        components
          .card
          .backgroundColor,

      borderWidth:
        components
          .card
          .borderWidth,

      borderColor:
        components
          .card
          .borderColor,

      padding:
        spacing.md,

      ...shadows.card,
    },


    /* ------------------------------------------
     * AMOUNT
     * ------------------------------------------ */

    amountIconWrap: {
      width:
        34,

      height:
        34,

      borderRadius:
        radii.circle,

      alignItems:
        'center',

      justifyContent:
        'center',

      marginBottom:
        spacing.xs,
    },


    /* ------------------------------------------
     * PARTIES
     * ------------------------------------------ */

    partiesCard: {
      flexDirection:
        'row',

      alignItems:
        'stretch',

      width:
        '100%',

      justifyContent:
        'space-between',

      flex: 1,
    },

    partiesDivider: {
      width:
        components
          .divider
          .thickness,

      backgroundColor:
        colors
          .border
          .light,

      marginHorizontal:
        spacing.sm,
    },

    partyLabel: {
      ...typography.caption,

      color:
        colors
          .brand
          .primary,

      marginBottom:
        spacing.xxs,
    },


    /* ------------------------------------------
     * INFORMATION
     * ------------------------------------------ */

    collapseHeader: {
      flexDirection:
        'row',

      alignItems:
        'center',

      gap:
        spacing.xs,

      paddingVertical:
        spacing.xs,
    },

    infoSection: {
      paddingBottom:
        spacing.xs,
    },

    infoRow: {
      flexDirection:
        'row',

      alignItems:
        'center',

      gap:
        spacing.sm,

      paddingVertical:
        spacing.xs,
    },

    infoRowBorder: {
      borderBottomWidth:
        components
          .divider
          .thickness,

      borderBottomColor:
        components
          .divider
          .color,
    },


    /* ------------------------------------------
     * TRACKING
     * ------------------------------------------ */

    suiviHeader: {
      flexDirection:
        'row',

      alignItems:
        'center',

      gap:
        spacing.xs,

      marginBottom:
        spacing.xs,
    },

    suiviBadge: {
      paddingHorizontal:
        spacing.sm,

      paddingVertical:
        3,

      borderRadius:
        radii.pill,
    },

    stepRow: {
      flexDirection:
        'row',

      gap:
        spacing.sm,
    },

    stepRowCurrent: {
      backgroundColor:
        colors
          .brand
          .primaryLight,

      marginHorizontal:
        -spacing.sm,

      paddingHorizontal:
        spacing.sm,

      borderRadius:
        radii.sm,
    },

    stepRail: {
      alignItems:
        'center',

      width:
        16,
    },

    stepLine: {
      flex: 1,

      width:
        components
          .divider
          .thickness *
        2,

      backgroundColor:
        colors
          .border
          .light,

      marginTop:
        2,

      minHeight:
        12,
    },


    /* ------------------------------------------
     * PROOF
     * ------------------------------------------ */

    proofRow: {
      flexDirection:
        'row',

      alignItems:
        'center',

      gap:
        spacing.xs,

      marginTop:
        spacing.xs,

      paddingTop:
        spacing.sm,

      borderTopWidth:
        components
          .divider
          .thickness,

      borderTopColor:
        components
          .divider
          .color,
    },

    proofButton: {
      backgroundColor:
        colors
          .brand
          .primary,

      borderRadius:
        radii.pill,

      paddingHorizontal:
        spacing.sm,

      paddingVertical:
        spacing.xxs,
    },

    proofButtonText: {
      ...typography.overline,

      color:
        colors
          .text
          .inverse,
    },


    /* ------------------------------------------
     * CANCEL
     * ------------------------------------------ */

    cancelLink: {
      alignItems:
        'center',

      paddingVertical:
        spacing.xxs,
    },


    /* ------------------------------------------
     * CLOSED NOTICE
     * ------------------------------------------ */

    notice: {
      flexDirection:
        'row',

      alignItems:
        'center',

      gap:
        spacing.sm,

      backgroundColor:
        components
          .infoBanner
          .backgroundColor,

      borderRadius:
        components
          .infoBanner
          .radius,

      padding:
        spacing.sm,
    },


    /* ------------------------------------------
     * ACTIONS
     * ------------------------------------------ */

    bottomActionsRow: {
      flexDirection:
        'row',

      gap:
        spacing.sm,
    },
  });